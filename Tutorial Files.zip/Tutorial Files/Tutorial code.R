# Load StereoMorph library
library(StereoMorph)


############################# Create Checkerboard Pattern ################################

# Load StereoMorph library
library(StereoMorph)

# Where to save checkerboard pattern
filename <- 'Checkerboard 21x14 (150px).JPG'

# Create checkerboard pattern
drawCheckerboard(nx=21, ny=14, square.size=150, filename)


######################### Auto-detecting checkerboard corners ############################

# Load StereoMorph library
library(StereoMorph)

# Set number of internal corners in x and y
nx <- 21
ny <- 14

# Find internal corners in a single image
# Set file location of image, where to save corners and where to save "check" image
image.file <- 'Calibration images/v1/DSC_0002.JPG'
corner.file <- 'Calibration corners/v1/DSC_0002.txt'
verify.file <- 'Calibration images verify/v1/DSC_0002.JPG'

# Find the internal corners of the checkerboard pattern
corners <- findCheckerboardCorners(image.file=image.file, nx=nx, ny=ny,
	corner.file=corner.file, verify.file=verify.file)

image.file <- 'Calibration images/v2'
corner.file <- 'Calibration corners/v2'
verify.file <- 'Calibration images verify/v2'

# Find the internal corners of the checkerboard pattern
corners <- findCheckerboardCorners(image.file=image.file, nx=nx, ny=ny,
	corner.file=corner.file, verify.file=verify.file)


########################## Measuring checkerboard square size ############################

# Load StereoMorph library
library(StereoMorph)

# Specify location of image with checkerboard and ruler
image.file <- 'Measure square size/Checkerboard 6p.JPG'

# Specify where to save the corners
corner.file <- 'Measure square size corners/Checkerboard 6p.txt'
verify.file <- 'Measure square size verify/Checkerboard 6p.JPG'

# Specify the number of internal corners in the checkerboard
nx <- 21
ny <- 14

# Find the internal corners of the checkerboard pattern
corners <- findCheckerboardCorners(image.file=image.file, nx=nx, ny=ny, 
	corner.file=corner.file, verify.file=verify.file)

# Specify where to save the manually digitized ruler points, start with an empty file
landmarks.file <- 'Measure square size ruler/Checkerboard 6p t.txt'

# Specify a text file containing a list of the points to be collected (mm_pt001, mm_pt002, etc.)
landmarks.ref <- 'Ruler points mm.txt'

# This input can also be a vector
landmarks.ref <- paste0('mm_pt', formatC(1:200, NULL, 3, "d", "0"))

# Launch the digitizing app
digitizeImage(image.file=image.file, landmarks.file=landmarks.file, landmarks.ref=landmarks.ref)

# Specify the file with already digitized ruler points
landmarks.file <- 'Measure square size ruler/Checkerboard 6p.txt'

# Launch the digitizing app
digitizeImage(image.file=image.file, landmarks.file=landmarks.file, landmarks.ref=landmarks.ref)

# Set the distance between the ruler points
ruler.pt.size <- '1 mm'

# Measure the checkerboard size using the ruler points
measure <- measureCheckerboardSize(corner.file=corner.file, nx=nx, 
	ruler.file=landmarks.file, ruler.pt.size=ruler.pt.size)

# Print a summary of the results
print(summary(measure))

# Print the estimated square size
print(measure$square.size.rwu)


################################ Calibrate the cameras ###################################

# Load StereoMorph library
library(StereoMorph)

# Specify the number of internal corners in the checkerboard
nx <- 21
ny <- 14

# Specify the file locations of the calibration images, where to save the checkerboard 
#	corners and, if desired, where to save the verification images
image_file <- paste0('Calibration images/v', c(1, 2))
corner_file <- paste0('Calibration corners/v', c(1, 2))
verify_file <- paste0('Calibration images verify/v', c(1, 2))

# Call findCheckerboardCorners()
corners <- findCheckerboardCorners(image.file=image_file, nx=nx, ny=ny, 
	corner.file=corner_file, verify.file=verify_file)

# Make a matrix of corner file paths, columns 1 and 2 correspond to views 1 and 2, respectively
corners_by_file <- cbind(
	paste0(corner_file[1], '/', paste0('DSC_000', 2:9, '.txt')),
	paste0(corner_file[2], '/', paste0('DSC_000', 2:9, '.txt')))

# Read the corner matrices into an array
corners <- readCheckerboardsToArray(file=corners_by_file, nx=nx, ny=ny,
	col.reverse=c(F, T), row.reverse=c(F, T))

# Set the square size of the calibration checkerboard pattern
grid_size_cal <- 6.364643

# Calibrate the cameras using the first 6 image pairs
dlt_cal_cam <- dltCalibrateCameras(coor.2d=corners[, , 1:6, ], nx=nx, 
	grid.size=grid_size_cal, print.progress=TRUE)

# Show a summary of the calibration optimization
summary(dlt_cal_cam)

# Print the calibration coefficients
dlt_cal_cam$cal.coeff

# Save the calibration coefficients to a text file
write.table(x=dlt_cal_cam$cal.coeff, file="cal_coeffs.txt",
   row.names=F, col.names=F, sep="\t")


########################### Testing the calibration accuracy #############################

# Load StereoMorph library
library(StereoMorph)

# Specify the number of internal corners in the checkerboard
nx <- 21
ny <- 14

# Specify the file locations of the calibration images, where to save the checkerboard 
#	corners and, if desired, where to save the verification images
test_image_file <- paste0('Test images/v', c(1, 2))
test_corner_file <- paste0('Test corners/v', c(1, 2))
test_verify_file <- paste0('Test images verify/v', c(1, 2))

# Call findCheckerboardCorners()
test_corners <- findCheckerboardCorners(image.file=test_image_file, nx=nx, ny=ny,
	corner.file=test_corner_file, verify.file=test_verify_file)

# Make a matrix of corner file paths, columns 1 and 2 correspond to views 1 and 2, respectively
corners_by_file <- cbind(
	paste0(test_corner_file[1], '/', paste0('DSC_00', 11:18, '.txt')),
	paste0(test_corner_file[2], '/', paste0('DSC_00', 11:18, '.txt')))

# Read the corner matrices into an array
test_corners <- readCheckerboardsToArray(file=corners_by_file, nx=nx, ny=ny,
	col.reverse=c(F, T), row.reverse=c(F, T))

# Set the square size of the test calibration checkerboard pattern
grid_size_test <- 4.232748

# Load in the calibration coefficients
cal.coeff <- as.matrix(read.table("cal_coeffs.txt"))

# Call dltTestCalibration()
dlt_test <- dltTestCalibration(cal.coeff=cal.coeff, coor.2d=test_corners, nx=nx, 
	grid.size=grid_size_test)

# Show a summary of the accuracy test
summary(dlt_test)

# Plot a histogram of inter-point distance errors (in mm)
dev.new()
hist(dlt_test$ipd.error, breaks=20)

# Plot a histogram of adjacent inter-point distance errors (in mm)
dev.new()
hist(dlt_test$adj.pair.ipd.error, breaks=20)

# Plot the adjacent inter-point distance as a function of the distance of each adjacent 
#	pair from the centroid of all adjacent pairs
dev.new()
plot(dlt_test$adj.pair.centroid.dist, dlt_test$adj.pair.ipd.error)

# Plot the adjacent inter-point distance as a function of the mean position of each 
#	adjacent pair along the z-axis.
dev.new()
plot(dlt_test$adj.pair.mean.pos[, 3], dlt_test$adj.pair.ipd.error)


################################# Digitizing Photographs #################################

# Load StereoMorph
library(StereoMorph)

# Digitize landmarks and curves
digitizeImage(image.file = 'Object Images', landmarks.file = 'Landmarks 2D', 
   control.points.file = 'Control points 2D', curve.points.file = 'Curve points 2D', 
   landmarks.ref = 'landmarks_ref.txt', curves.ref = 'curves_ref.txt')

# Digitize landmarks only
digitizeImage(image.file = 'Object Images', landmarks.file = 'Landmarks 2D',
	landmarks.ref = 'landmarks_ref.txt')

# Check the pixel coordinates of a feature in a photograph
digitizeImage(image.file = 'Object Images')


###################### Reconstructing 2D Points and Curves into 3D #######################

# Load StereoMorph and rgl libraries
library(StereoMorph)
library(rgl)

# Read in calibration coefficients
cal.coeff <- as.matrix(read.table("cal_coeffs.txt"))


# Reconstruct landmarks only
# Specify location of landmark files
landmarks_2d <- paste0("Landmarks 2D/obj_a1_v", 1:2, ".txt")

# Read landmarks into matrix
lm_matrix <- readLandmarksToMatrix(landmarks_2d, row.names=1)

# Reconstruct the landmarks
dlt_recon <- dltReconstruct(cal.coeff, lm_matrix)

# Print summary
summary(dlt_recon)

# Get points to plot
pts <- na.omit(dlt_recon$coor.3d)

# Set aspect ratios so that points are displayed in proper proportions
r <- apply(pts, 2, 'max') - apply(pts, 2, 'min')

# Plot points using the rgl function plot3d()
plot3d(pts, aspect=c(r/r[3]), size=5)

# Save the landmarks from the first aspect to a text file
write.table(dlt_recon$coor.3d , file = "Landmarks 3D/obj_a1.txt",
	quote=F, sep="\t", col.names=F, row.names=T)

# Repeat for final two aspects
for(i in 2:3){
	landmarks_2d <- paste0("Landmarks 2D/obj_a", i, "_v", 1:2, ".txt")
	lm_matrix <- readLandmarksToMatrix(landmarks_2d, row.names=1)
	dlt_recon <- dltReconstruct(cal.coeff, lm_matrix)
	write.table(dlt_recon$coor.3d , 
		file = paste0("Landmarks and curves 3D/obj_a", i, ".txt"),
		quote=F, sep="\t", col.names=F, row.names=T)
}


# Reconstruct landmarks and curves
# Specify location of curve point files
curves_2d <- paste0("Curve points 2D/obj_a1_v", 1:2, ".txt")

# Read curve points into list
cp_list <- readLandmarksToList(curves_2d, row.names=1)

# Find corresponding points between the two views
dlt_mcp <- dltMatchCurvePoints(cp_list, cal.coeff, min.tangency.angle=0.3)

# Print first four points of 'pterygoid_crest_R' in view 1
print(cp_list$pterygoid_crest_R[[1]][1:4,])

# Print number of rows in curve point matrix of both views
cat(nrow(cp_list$tomium_R[[1]]), nrow(cp_list$tomium_R[[2]]))

# Convert matched curve point list to matrix
cp_matrix <- landmarkListToMatrix(dlt_mcp$match.lm.list)

# Specify location of landmark files
landmarks_2d <- paste0("Landmarks 2D/obj_a1_v", 1:2, ".txt")

# Read landmarks into matrix
lm_matrix <- readLandmarksToMatrix(landmarks_2d, row.names=1)

# Reconstruct the matching 2D curve points and landmarks
dlt_recon <- dltReconstruct(cal.coeff, rbind(cp_matrix, lm_matrix))

# Plot points using the rgl function plot3d()
pts <- na.omit(dlt_recon$coor.3d)
r <- apply(pts, 2, 'max') - apply(pts, 2, 'min')
plot3d(pts, aspect=c(r/r[3]), size=1)


# Generate evenly spaced points along each curve
# Convert the 3D coordinate matrix into a list
lm.list <- landmarkMatrixToList(dlt_recon$coor.3d)

# Call pointsAtEvenSpacing() for each curve, overwriting the existing entry in lm.list
lm.list$pterygoid_crest_R <- pointsAtEvenSpacing(x=lm.list$pterygoid_crest_R, n=10)
lm.list$tomium_R <- pointsAtEvenSpacing(x=lm.list$tomium_R, n=50)

# Plot points using the rgl function plot3d()
pts <- na.omit(dlt_recon$coor.3d)
r <- apply(pts, 2, 'max') - apply(pts, 2, 'min')
plot3d(pts, aspect=c(r/r[3]), size=1)

# Plot new down-sampled curve points
lm.matrix <- landmarkListToMatrix(lm.list)
plot3d(na.omit(lm.matrix), size=4, col='red', add=TRUE)

# Convert the landmark list into a matrix
lm.matrix <- landmarkListToMatrix(lm.list)

# Write the landmarks and curve points to a text file
write.table(lm.matrix, file="Landmarks and curves 3D/obj_a1.txt", quote=F,
	sep="\t", col.names=F, row.names=T)


########################### Unifying, Reflecting and Aligning ############################

# Unify landmarks
# Load StereoMorph and rgl libraries
library(StereoMorph)
library(rgl)

# Specify location of files containing 3D landmarks and curve points from different aspects
landmarks_3d <- paste0("Landmarks and curves 3D/obj_a", 1:3, ".txt")

# Read the landmarks into an array
lm.array <- readLandmarksToArray(landmarks_3d, row.names=1)

# Unify the three aspects into a single point set
unify_lm <- unifyLandmarks(lm.array, min.common=5)

# Print a summary of the unification errors
summary(unify_lm)

# Plot points using the rgl function plot3d()
pts <- na.omit(unify_lm$lm.matrix)
r <- apply(pts, 2, 'max') - apply(pts, 2, 'min')
plot3d(pts, aspect=c(r/r[3]), size=3)

# Write the unified landmarks and curve points to a text file
write.table(unify_lm$lm.matrix, file="Unified landmarks/obj.txt", quote=F,
	sep="\t", col.names=F, row.names=T)


# Reflect missing landmarks
# Specify location of files containing 3D landmarks and curve points
lm_unified <- paste0("Unified landmarks/obj.txt")

# Read the landmarks into an array
lm.matrix <- readLandmarksToMatrix(lm_unified, row.names=1)

# Reflect the missing landmarks across the plane of bilateral symmetry
reflect <- reflectMissingLandmarks(lm.matrix, average=TRUE)

# If you have just completed the unification step, you can use unify_lm$lm.matrix
reflect <- reflectMissingLandmarks(unify_lm$lm.matrix, average=TRUE)

# Plot points using the rgl function plot3d()
pts <- na.omit(reflect$lm.matrix)
r <- apply(pts, 2, 'max') - apply(pts, 2, 'min')
plot3d(pts, aspect=c(r/r[3]), size=3)

# Write the reflected landmarks and curve points to a text file
write.table(reflect$lm.matrix, file="Landmarks 3D reflected/obj.txt", 
  quote=F, sep="\t", col.names=F, row.names=T)


# Align landmarks to the midline plane
# Specify location of files containing 3D landmarks and curve points
lm_reflected <- paste0("Landmarks 3D reflected/obj.txt")

# Read the landmarks into an array
lm.matrix <- readLandmarksToMatrix(lm_reflected, row.names=1)

# Align the landmarks to the midline
align <- alignLandmarksToMidline(lm.matrix)

# If you have just completed the reflection step, you can use reflect$lm.matrix
align <- alignLandmarksToMidline(reflect$lm.matrix)

# Plot points using the rgl function plot3d()
pts <- na.omit(align$lm.matrix)
r <- apply(pts, 2, 'max') - apply(pts, 2, 'min')
plot3d(pts, aspect=c(r/r[3]), size=3)

# Note that left and right landmark pairs have the same coordinates except being opposite 
#	along the z-axis
align$lm.matrix['quadrate_jugal_L', ]
align$lm.matrix['quadrate_jugal_R', ]

# Write the aligned landmarks and curve points to a text file
write.table(align$lm.matrix, file="Landmarks 3D aligned/obj.txt", quote=F, sep="\t", 
	col.names=F, row.names=T)


########################### 2D Morphometrics with StereoMorph ############################

# Load StereoMorph library
library(StereoMorph)

# Set the working directory to the '2D Morphometrics' folder within the StereoMorph 
#	Tutorial folder
setwd('2D Morphometrics')

# Digitize landmarks and curves
digitizeImage(image.file = 'Object Images', 
	landmarks.file = 'Landmarks px', 
	control.points.file = 'Control points', 
	curve.points.file = 'Curves px', 
	landmarks.ref = 'landmarks_ref.txt', 
	curves.ref = 'curves_ref.txt')

# Set number of internal corners in x and y
nx <- 5
ny <- 3

# Find the internal corners of the checkerboard pattern
find_corners <- findCheckerboardCorners(image.file='Object images', nx=nx, ny=ny,
	corner.file='Corners', verify.file='Corners verify')

# Read checkerboard corners from first file
corners <- as.matrix(read.table('Corners/RHumerus.txt'))

# Measure checkerboard square size
measure <- measureCheckerboardSize(corners, nx=nx)

# The square size in pixels
square_size_px  <- measure$square.size.px

# The square size in real-world units
square_size_mm <- 10.001

# Ratio to convert pixels to real-world units (here, millimeters)
scale_px2mm <- square_size_mm / square_size_px

# Read in the landmarks and curve points
landmarks_px <- as.matrix(read.table('Landmarks px/RHumerus.txt', row.names=1))
curves_px <- as.matrix(read.table('Curves px/RHumerus.txt', row.names=1))

# Scale the landmarks and curve points
landmarks_mm <- landmarks_px * (square_size_mm / square_size_px)
curves_mm <- curves_px * (square_size_mm / square_size_px)

# Plot landmarks and curve points
dev.new()
plot(curves_mm, cex=0.1, asp=1)
points(landmarks_mm, cex=0.5, col='blue')

# Write landmarks and curve points to a file
write.table(landmarks_mm , file = "Landmarks mm/RHumerus.txt", quote=F, sep="\t", 
	col.names=F, row.names=T)
write.table(curves_mm , file = "Curves mm/RHumerus.txt", quote=F, sep="\t", 
	col.names=F, row.names=T)


nx <- 5
ny <- 3

find_corners <- findCheckerboardCorners(image.file='Object images', nx=nx, ny=ny,
	corner.file='Corners', verify.file='Corners verify')

filenames <- gsub('.jpg|.jpeg', '.txt', list.files('Object images'), ignore.case=TRUE)

square_size_mm <- 10.001

for(filename in filenames){
    corners <- as.matrix(read.table(paste0('Corners/', filename)))
    measure <- measureCheckerboardSize(corners, nx=nx)
    scale_px2mm <- square_size_mm / measure$square.size.px
    landmarks_px <- as.matrix(read.table(paste0('Landmarks px/', filename), row.names=1))
    curves_px <- as.matrix(read.table(paste0('Curves px/', filename), row.names=1))
    landmarks_mm <- landmarks_px * scale_px2mm
    curves_mm <- curves_px * scale_px2mm
	write.table(landmarks_mm, file = paste0('Landmarks mm/', filename), quote=F, sep='\t', 
		col.names=F, row.names=T)
	write.table(curves_mm, file = paste0('Curves mm/', filename), quote=F, sep='\t', 
		col.names=F, row.names=T)
}
